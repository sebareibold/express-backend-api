// Servicio para manejar WebSockets
class SocketService {
  constructor() {
    this.io = null
  }

  // Inicializar el servicio con la instancia de Socket.io
  init(io) {
    if (this.io) {
      console.log("✅ Socket service ya fue inicializado")
      return
    }

    this.io = io

    // Configurar eventos de conexión
    this.io.on("connection", (socket) => {
      console.log(`🔌 Nuevo cliente conectado: ${socket.id}`)

      // Enviar productos actuales al cliente recién conectado
      this.sendCurrentProducts(socket)

      socket.on("disconnect", () => {
        console.log(`🔌 Cliente desconectado: ${socket.id}`)
      })

      socket.on("error", (error) => {
        console.error(`❌ Error en socket ${socket.id}:`, error)
      })
    })

    console.log("✅ Socket Service inicializado exitosamente!")
  }

  // Enviar productos actuales a un cliente específico
  async sendCurrentProducts(socket) {
    try {
      const productManager = require("../managers/ProductsManager")
      const products = await productManager.getProducts()
      socket.emit("productListUpdate", products)
      console.log(`📦 Productos enviados al cliente ${socket.id}`)
    } catch (error) {
      console.error("Error al enviar productos actuales:", error)
    }
  }

  // Método para emitir actualizaciones de productos
  emitProductUpdate(products) {
    if (!this.io) {
      console.log("❌ Socket service no inicializado")
      return
    }

    this.io.emit("productListUpdate", products)
    console.log(`📡 Actualización de productos emitida a ${this.io.engine.clientsCount} clientes`)
  }

  // Obtener número de clientes conectados
  getConnectedClients() {
    return this.io ? this.io.engine.clientsCount : 0
  }
}

// Singleton para usar en toda la aplicación
const socketService = new SocketService()
module.exports = socketService
